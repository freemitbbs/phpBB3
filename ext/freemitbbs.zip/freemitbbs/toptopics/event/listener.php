<?php

namespace freemitbbs\toptopics\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	protected \phpbb\auth\auth $auth;
	protected \phpbb\config\config $config;
	protected \phpbb\db\driver\driver_interface $db;
	protected \phpbb\request\request_interface $request;
	protected \phpbb\template\template $template;
	protected \phpbb\user $user;
	protected \phpbb\language\language $language;
	protected \phpbb\controller\helper $helper;
	protected \freemitbbs\toptopics\service\ranker $ranker;
	protected \freemitbbs\toptopics\service\cache_invalidator $cache_invalidator;
	protected \freemitbbs\toptopics\service\reputation $reputation;
	protected $topicpreview_data;
	protected $topicpreview_renderer;
	protected $collapsible_operator;
	protected string $dislikes_table;
	protected string $dislike_history_table;
	protected string $topic_overrides_table;
	protected string $user_reputation_table;
	protected string $root_path;
	protected string $php_ext;

	protected array $post_dislike_counts = [];
	protected array $user_disliked_posts = [];
	protected array $user_reputation_scores = [];
	protected ?int $current_user_reputation = null;
	protected array $index_category_blocks = [];

	public function __construct(
		\phpbb\auth\auth $auth,
		\phpbb\config\config $config,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\request\request_interface $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		\phpbb\language\language $language,
		\phpbb\controller\helper $helper,
		\freemitbbs\toptopics\service\ranker $ranker,
		\freemitbbs\toptopics\service\cache_invalidator $cache_invalidator,
		\freemitbbs\toptopics\service\reputation $reputation,
		$topicpreview_data,
		$topicpreview_renderer,
		$collapsible_operator,
		string $dislikes_table,
		string $dislike_history_table,
		string $topic_overrides_table,
		string $user_reputation_table,
		string $root_path,
		string $php_ext
	)
	{
		$this->auth = $auth;
		$this->config = $config;
		$this->db = $db;
		$this->request = $request;
		$this->template = $template;
		$this->user = $user;
		$this->language = $language;
		$this->helper = $helper;
		$this->ranker = $ranker;
		$this->cache_invalidator = $cache_invalidator;
		$this->reputation = $reputation;
		$this->topicpreview_data = $topicpreview_data;
		$this->topicpreview_renderer = $topicpreview_renderer;
		$this->collapsible_operator = $collapsible_operator;
		$this->dislikes_table = $dislikes_table;
		$this->dislike_history_table = $dislike_history_table;
		$this->topic_overrides_table = $topic_overrides_table;
		$this->user_reputation_table = $user_reputation_table;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	public static function getSubscribedEvents()
	{
			return [
				'core.user_setup' => 'load_language_on_setup',
				'core.permissions' => 'add_permissions',
				'core.viewtopic_modify_post_data' => 'prefetch_dislikes',
				'core.viewtopic_modify_post_row' => 'modify_post_row',
				'core.viewtopic_modify_page_title' => 'viewtopic_admin_override',
				'core.display_forums_before' => 'index_category_blocks',
				'core.display_forums_modify_category_template_vars' => 'display_forums_modify_category_template_vars',
				'core.report_post_auth' => 'report_post_auth',
				'core.index_modify_page_title' => 'index_page_summary',
				'core.viewforum_modify_page_title' => 'forum_page_summary',
				'core.submit_post_end' => 'submit_post_end',
				'core.set_post_visibility_after' => 'post_visibility_after',
				'core.set_topic_visibility_after' => 'topic_visibility_after',
				'core.notification_manager_add_notifications' => 'report_notification_added',
				'core.add_log' => 'report_log_added',
				'core.delete_posts_after' => 'clean_posts_after',
				'core.delete_user_after' => 'clean_users_after',
			];
		}

	public function load_language_on_setup($event)
	{
		$this->language->add_lang('toptopics', 'freemitbbs/toptopics');
	}

	public function add_permissions($event)
	{
		$permissions = $event['permissions'];
		$permissions['u_toptopics_dislike'] = ['lang' => 'ACL_U_TOPTOPICS_DISLIKE', 'cat' => 'misc'];
		$event['permissions'] = $permissions;
	}

	public function prefetch_dislikes($event)
	{
		$post_list = array_map('intval', $event['post_list']);
		if (empty($post_list))
		{
			return;
		}

		$sql = 'SELECT post_id, COUNT(user_id) AS dislike_count
			FROM ' . $this->dislikes_table . '
			WHERE ' . $this->db->sql_in_set('post_id', $post_list) . '
			GROUP BY post_id';
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$this->post_dislike_counts[(int) $row['post_id']] = (int) $row['dislike_count'];
		}
		$this->db->sql_freeresult($result);

		$user_ids = [];
		foreach (($event['rowset'] ?? []) as $row)
		{
			$user_id = (int) ($row['user_id'] ?? ANONYMOUS);
			if ($user_id !== ANONYMOUS)
			{
				$user_ids[] = $user_id;
			}
		}

		if ((int) $this->user->data['user_id'] !== ANONYMOUS)
		{
			$user_ids[] = (int) $this->user->data['user_id'];
		}

		$this->user_reputation_scores = $this->reputation->get_scores($user_ids);
		if ((int) $this->user->data['user_id'] !== ANONYMOUS)
		{
			$this->current_user_reputation = $this->user_reputation_scores[(int) $this->user->data['user_id']] ?? 0;
		}

		if ($this->user->data['user_id'] == ANONYMOUS)
		{
			return;
		}

		$sql = 'SELECT post_id
			FROM ' . $this->dislikes_table . '
			WHERE user_id = ' . (int) $this->user->data['user_id'] . '
				AND ' . $this->db->sql_in_set('post_id', $post_list);
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$this->user_disliked_posts[(int) $row['post_id']] = true;
		}
		$this->db->sql_freeresult($result);
	}

	public function modify_post_row($event)
	{
		$post_id = (int) $event['row']['post_id'];
		$poster_id = isset($event['poster_id']) ? (int) $event['poster_id'] : (int) ($event['row']['user_id'] ?? ANONYMOUS);
		$current_user_id = (int) $this->user->data['user_id'];
		$dislike_count = $this->post_dislike_counts[$post_id] ?? 0;
		$current_user_disliked = !empty($this->user_disliked_posts[$post_id]);

		$disabled = false;
		$action = $current_user_disliked ? $this->language->lang('CLICK_TO_UNDISLIKE') : $this->language->lang('CLICK_TO_DISLIKE');

		if ($current_user_id == ANONYMOUS || !$this->auth->acl_get('u_toptopics_dislike'))
		{
			$disabled = true;
			$action = $this->language->lang('LOGIN_TO_DISLIKE_POST');
		}
		else if ($poster_id === $current_user_id)
		{
			$disabled = true;
			$action = $this->language->lang('CANT_DISLIKE_OWN_POST');
		}
		else if ((int) $this->user->data['user_posts'] < (int) $this->config['toptopics_downvote_min_posts'])
		{
			$disabled = true;
			$action = $this->language->lang('TOPTOPICS_MIN_POSTS_TO_DISLIKE', (int) $this->config['toptopics_downvote_min_posts']);
		}
		else if ($this->reputation->get_required_dislike_score() > 0
			&& $this->get_current_user_reputation() < $this->reputation->get_required_dislike_score())
		{
			$disabled = true;
			$action = $this->language->lang(
				'TOPTOPICS_MIN_REPUTATION_TO_DISLIKE',
				$this->format_reputation($this->reputation->get_required_dislike_score()),
				$this->format_reputation($this->get_current_user_reputation())
			);
		}

		$post_row = $event['post_row'];
		$post_row['POST_DISLIKE_CLASS'] = $current_user_disliked ? 'toptopics-disliked' : 'toptopics-dislike';
		$post_row['POST_DISLIKE_COUNT'] = $dislike_count;
		$post_row['POST_DISLIKERS'] = $this->language->lang('TOPTOPICS_DISLIKES_COUNT', $dislike_count);
		$post_row['POST_DISLIKE_ACTION'] = $action;
		$post_row['POST_DISLIKE_URL'] = $this->build_dislike_url($post_id, $current_user_disliked);
		$post_row['POST_DISLIKE_DISABLED'] = $disabled;
		if ($poster_id !== ANONYMOUS)
		{
			$post_row['S_TOPTOPICS_USER_REPUTATION'] = true;
			$post_row['USER_REPUTATION'] = $this->user_reputation_scores[$poster_id] ?? 0;
		}

		$forum_id = (int) ($event['row']['forum_id'] ?? 0);
		if (!empty($post_row['U_REPORT']) && !$this->can_current_user_report($forum_id))
		{
			$post_row['U_REPORT'] = '';
		}

		$event['post_row'] = $post_row;
	}

	public function report_post_auth($event): void
	{
		$forum_id = (int) ($event['report_data']['forum_id'] ?? 0);
		if ($forum_id <= 0 || $this->can_current_user_report($forum_id))
		{
			return;
		}

		throw new \phpbb\report\exception\report_permission_denied_exception($this->language->lang(
			'TOPTOPICS_MIN_REPUTATION_TO_REPORT',
			$this->format_reputation($this->reputation->get_required_report_score()),
			$this->format_reputation($this->get_current_user_reputation())
		));
	}

	public function viewtopic_admin_override($event): void
	{
		$topic_id = (int) ($event['topic_data']['topic_id'] ?? 0);
		$forum_id = (int) ($event['forum_id'] ?? 0);

		if (!$topic_id
			|| $this->user->data['is_bot']
			|| !$this->auth->acl_get('a_board')
			|| !$this->auth->acl_get('f_read', $forum_id))
		{
			return;
		}

		$current_state = $this->get_topic_override_state($topic_id);

		$this->template->assign_vars([
			'S_TOPTOPICS_ADMIN_OVERRIDE' => true,
			'TOPTOPICS_OVERRIDE_CURRENT' => $this->language->lang('TOPTOPICS_OVERRIDE_CURRENT_' . strtoupper($current_state ?: 'NORMAL')),
			'U_TOPTOPICS_OVERRIDE_NORMAL' => $this->build_override_url($topic_id, 'normal'),
			'U_TOPTOPICS_OVERRIDE_BOOST' => $this->build_override_url($topic_id, 'boost'),
			'U_TOPTOPICS_OVERRIDE_DEMOTE' => $this->build_override_url($topic_id, 'demote'),
			'U_TOPTOPICS_OVERRIDE_KILL' => $this->build_override_url($topic_id, 'kill'),
			'S_TOPTOPICS_OVERRIDE_NORMAL' => $current_state === '',
			'S_TOPTOPICS_OVERRIDE_BOOST' => $current_state === 'boost',
			'S_TOPTOPICS_OVERRIDE_DEMOTE' => $current_state === 'demote',
			'S_TOPTOPICS_OVERRIDE_KILL' => $current_state === 'kill',
		]);
	}

	public function index_category_blocks($event): void
	{
		$root_data = $event['root_data'] ?? [];
		if ((int) ($root_data['forum_id'] ?? -1) !== 0)
		{
			return;
		}

		$this->index_category_blocks = [];

		$forum_rows = $event['forum_rows'] ?? [];
		if (empty($forum_rows))
		{
			return;
		}

		$category_rows = [];
		foreach ($forum_rows as $forum_id => $row)
		{
			$forum_id = (int) $forum_id;
			if ((int) ($row['forum_type'] ?? FORUM_POST) === FORUM_CAT
				&& (int) ($row['parent_id'] ?? 0) === 0)
			{
				$category_rows[$forum_id] = $row;
				$this->index_category_blocks[$forum_id] = [];
			}
		}

		if (empty($category_rows))
		{
			return;
		}

		$topicpreview = $this->get_topicpreview_context();
		if ($topicpreview['enabled'])
		{
			$this->assign_topicpreview_template_vars($topicpreview);
		}

		$category_forums = [];
		foreach ($forum_rows as $row)
		{
			$parent_id = (int) ($row['parent_id'] ?? 0);
			if ((int) ($row['forum_type'] ?? FORUM_POST) !== FORUM_CAT && isset($category_rows[$parent_id]))
			{
				$category_forums[$parent_id][] = $row;
			}
		}

		if (empty($category_forums))
		{
			return;
		}

		$all_topics = [];
		foreach ($category_forums as $category_id => $forums)
		{
			$topic_forum_ids = [];
			foreach ($forums as $forum)
			{
				if ((int) ($forum['forum_type'] ?? FORUM_POST) === FORUM_POST)
				{
					$topic_forum_ids[] = (int) $forum['forum_id'];
				}
			}

			$topics = !empty($topic_forum_ids)
				? $this->ranker->get_topics($topic_forum_ids, (int) $this->config['toptopics_forum_limit'])
				: [];

			$this->index_category_blocks[$category_id] = [
				'forum_menu_html' => $this->build_category_forum_menu_html($forums, $category_id),
				'topic_ids' => array_map('intval', array_column($topics, 'topic_id')),
				'rows_html' => '',
			];

			foreach ($topics as $topic)
			{
				$all_topics[(int) $topic['topic_id']] = $topic;
			}
		}

		if (empty($all_topics))
		{
			foreach ($this->index_category_blocks as $category_id => $block)
			{
				$this->index_category_blocks[$category_id]['rows_html'] = $this->build_category_rows_html([]);
				unset($this->index_category_blocks[$category_id]['topic_ids']);
			}
			return;
		}

		$decorated_topics = $this->decorate_topics(array_values($all_topics), $topicpreview['enabled'], $topicpreview);
		$decorated_by_id = [];
		foreach ($decorated_topics as $topic)
		{
			$decorated_by_id[(int) $topic['topic_id']] = $topic;
		}

		foreach ($this->index_category_blocks as $category_id => $block)
		{
			$category_topics = [];
			foreach ($block['topic_ids'] as $topic_id)
			{
				if (isset($decorated_by_id[$topic_id]))
				{
					$category_topics[] = $decorated_by_id[$topic_id];
				}
			}

			$this->index_category_blocks[$category_id]['rows_html'] = $this->build_category_rows_html($category_topics);
			unset($this->index_category_blocks[$category_id]['topic_ids']);
		}
	}

	public function display_forums_modify_category_template_vars($event): void
	{
		$category_id = (int) (($event['row']['forum_id'] ?? 0));
		if (!isset($this->index_category_blocks[$category_id]))
		{
			$this->index_category_blocks[$category_id] = $this->build_index_category_block($category_id);
		}

		if (empty($this->index_category_blocks[$category_id]))
		{
			return;
		}

		$cat_row = $event['cat_row'];
		$cat_row['S_TOPTOPICS_CATEGORY_BLOCK'] = true;
		$cat_row['TOPTOPICS_CATEGORY_FORUM_MENU'] = $this->index_category_blocks[$category_id]['forum_menu_html'];
		$cat_row['TOPTOPICS_CATEGORY_ROWS_HTML'] = $this->index_category_blocks[$category_id]['rows_html'];
		$event['cat_row'] = $cat_row;
	}

	public function index_page_summary($event)
	{
		if ($this->user->data['is_bot'])
		{
			return;
		}

		$forum_ids = $this->get_readable_forum_ids();
		$topics = $this->ranker->get_topics($forum_ids, (int) $this->config['toptopics_index_limit']);
		$this->template->assign_var(
			'S_TOPTOPICS_INDEX_BELOW',
			isset($this->config['postlove_summary_position']) ? (bool) $this->config['postlove_summary_position'] : true
		);
		$this->assign_summary($topics, 'S_TOPTOPICS_INDEX_ITEMS', $this->language->lang('TOPTOPICS_INDEX_TITLE'), true, 'toptopics_index');
	}

	public function forum_page_summary($event)
	{
		if ($this->user->data['is_bot'])
		{
			return;
		}

		$forum_id = (int) $event['forum_id'];
		$forum_ids = [$forum_id];
		$forum_read_ary = $this->auth->acl_getf('f_read');
		$forum_list_ary = $this->auth->acl_getf('f_list');
		$include_forum_name = false;

		if ((int) $event['forum_data']['left_id'] !== (int) $event['forum_data']['right_id'] - 1)
		{
			$include_forum_name = true;
			$sql = 'SELECT forum_id
				FROM ' . FORUMS_TABLE . '
				WHERE parent_id = ' . $forum_id;
			$result = $this->db->sql_query($sql);
			while ($row = $this->db->sql_fetchrow($result))
			{
				$child_forum_id = (int) $row['forum_id'];
				if (!empty($forum_read_ary[$child_forum_id]['f_read']) && !empty($forum_list_ary[$child_forum_id]['f_list']))
				{
					$forum_ids[] = $child_forum_id;
				}
			}
			$this->db->sql_freeresult($result);
		}

		$topics = $this->ranker->get_topics($forum_ids, (int) $this->config['toptopics_forum_limit']);
		$this->assign_summary($topics, 'S_TOPTOPICS_FORUM_ITEMS', $this->language->lang('TOPTOPICS_FORUM_TITLE'), $include_forum_name, 'toptopics_forum_' . $forum_id);
	}

	public function submit_post_end($event): void
	{
		$data = $event['data'] ?? [];
		$poster_id = (int) ($data['poster_id'] ?? $this->user->data['user_id'] ?? ANONYMOUS);
		if ($poster_id > 0 && $poster_id !== ANONYMOUS)
		{
			$this->reputation->refresh_user($poster_id);
		}
	}

	public function clean_posts_after($event)
	{
		$sql = 'DELETE FROM ' . $this->dislikes_table . '
			WHERE ' . $this->db->sql_in_set('post_id', array_map('intval', $event['post_ids']));
		$this->db->sql_query($sql);

		$sql = 'DELETE FROM ' . $this->dislike_history_table . '
			WHERE ' . $this->db->sql_in_set('post_id', array_map('intval', $event['post_ids']));
		$this->db->sql_query($sql);

		$this->reputation->refresh_users($event['poster_ids']);
		$this->invalidate_rank_cache_for_forums($event['forum_ids'] ?? []);
	}

	public function clean_users_after($event)
	{
		$sql = 'DELETE FROM ' . $this->dislikes_table . '
			WHERE ' . $this->db->sql_in_set('user_id', array_map('intval', $event['user_ids']));
		$this->db->sql_query($sql);

		$sql = 'DELETE FROM ' . $this->dislike_history_table . '
			WHERE ' . $this->db->sql_in_set('user_id', array_map('intval', $event['user_ids']));
		$this->db->sql_query($sql);

		$sql = 'DELETE FROM ' . $this->user_reputation_table . '
			WHERE ' . $this->db->sql_in_set('user_id', array_map('intval', $event['user_ids']));
		$this->db->sql_query($sql);

		$this->invalidate_all_rank_cache();
	}

	public function post_visibility_after($event): void
	{
		$forum_id = (int) ($event['forum_id'] ?? 0);
		if ($forum_id > 0)
		{
			$this->invalidate_rank_cache_for_forums([$forum_id]);
			$this->ranker->clear_materialized_scopes_for_forums([$forum_id]);
		}
		else
		{
			$this->invalidate_all_rank_cache();
		}

		$this->refresh_reputation_for_visibility_event($event);
	}

	public function topic_visibility_after($event): void
	{
		$forum_id = (int) ($event['forum_id'] ?? 0);
		if ($forum_id > 0)
		{
			$this->invalidate_rank_cache_for_forums([$forum_id]);
			$this->ranker->clear_materialized_scopes_for_forums([$forum_id]);
			return;
		}

		$this->invalidate_all_rank_cache();
	}

	public function report_notification_added($event): void
	{
		if (($event['notification_type_name'] ?? '') === 'notification.type.report_post')
		{
			$data = $event['data'] ?? [];
			$forum_id = (int) ($data['forum_id'] ?? 0);
			if ($forum_id > 0)
			{
				$this->invalidate_rank_cache_for_forums([$forum_id]);
			}
			else
			{
				$this->invalidate_all_rank_cache();
			}

			$post_id = (int) ($data['post_id'] ?? 0);
			if ($post_id > 0)
			{
				$this->refresh_reputation_for_post_ids([$post_id]);
			}
		}
	}

	public function report_log_added($event): void
	{
		if (($event['mode'] ?? '') !== 'mod')
		{
			return;
		}

		if (in_array((string) ($event['log_operation'] ?? ''), ['LOG_REPORT_CLOSED', 'LOG_REPORT_DELETED'], true))
		{
			$sql_ary = $event['sql_ary'] ?? [];
			$forum_id = (int) ($sql_ary['forum_id'] ?? 0);
			if ($forum_id > 0)
			{
				$this->invalidate_rank_cache_for_forums([$forum_id]);
			}
			else
			{
				$this->invalidate_all_rank_cache();
			}

			$post_id = (int) ($sql_ary['post_id'] ?? 0);
			if ($post_id > 0)
			{
				$this->refresh_reputation_for_post_ids([$post_id]);
			}
		}
	}

	protected function build_dislike_url(int $post_id, bool $current_user_disliked): string
	{
		return $this->helper->route('freemitbbs_toptopics_vote', [
			'action' => $current_user_disliked ? 'remove' : 'add',
			'post' => $post_id,
			'hash' => generate_link_hash('toptopics_dislike_' . $post_id),
		]);
	}

	protected function build_override_url(int $topic_id, string $state): string
	{
		return $this->helper->route('freemitbbs_toptopics_override', [
			'topic' => $topic_id,
			'state' => $state,
			'hash' => generate_link_hash('toptopics_override_' . $topic_id . '_' . $state),
		]);
	}

	protected function get_readable_forum_ids(): array
	{
		$forum_ids = [];
		$forum_list_ary = $this->auth->acl_getf('f_list');
		foreach ($this->auth->acl_getf('f_read') as $forum_id => $allowed)
		{
			if (!empty($allowed['f_read']) && !empty($forum_list_ary[$forum_id]['f_list']))
			{
				$forum_ids[] = (int) $forum_id;
			}
		}

		return array_values(array_unique($forum_ids));
	}

	protected function get_topic_override_state(int $topic_id): string
	{
		$sql = 'SELECT override_state
			FROM ' . $this->topic_overrides_table . '
			WHERE topic_id = ' . $topic_id;
		$result = $this->db->sql_query_limit($sql, 1);
		$state = (string) $this->db->sql_fetchfield('override_state');
		$this->db->sql_freeresult($result);

		return in_array($state, ['boost', 'demote', 'kill'], true) ? $state : '';
	}

	protected function build_category_forum_menu_html(array $forums, int $category_id): string
	{
		$html = '';
		foreach ($forums as $forum)
		{
			$url = append_sid($this->root_path . 'viewforum.' . $this->php_ext, 'f=' . (int) $forum['forum_id']);
			$name = $this->escape_text(censor_text((string) ($forum['forum_name'] ?? '')));
			$html .= '<a href="' . $url . '" class="toptopics-category-forum-link">' . $name . '</a>';
		}

		if (count($forums) > 1)
		{
			$more_url = append_sid($this->root_path . 'viewforum.' . $this->php_ext, 'f=' . $category_id);
			$html .= '<a href="' . $more_url . '" class="toptopics-category-forum-link toptopics-category-forum-more" aria-label="'
				. $this->escape_attr($this->language->lang('TOPTOPICS_CATEGORY_MORE'))
				. '">'
				. $this->escape_text($this->language->lang('TOPTOPICS_CATEGORY_MORE'))
				. '</a>';
		}

		return $html;
	}

	protected function build_index_category_block(int $category_id): array
	{
		if ($category_id <= 0)
		{
			return [];
		}

		$forum_read_ary = $this->auth->acl_getf('f_read');
		$forum_list_ary = $this->auth->acl_getf('f_list');
		$forums = [];
		$topic_forum_ids = [];

		$sql = 'SELECT forum_id, forum_name, forum_type
			FROM ' . FORUMS_TABLE . '
			WHERE parent_id = ' . $category_id . '
			ORDER BY left_id ASC';
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$forum_id = (int) $row['forum_id'];
			if (empty($forum_list_ary[$forum_id]['f_list']))
			{
				continue;
			}

			$forums[] = $row;
			if ((int) $row['forum_type'] === FORUM_POST && !empty($forum_read_ary[$forum_id]['f_read']))
			{
				$topic_forum_ids[] = $forum_id;
			}
		}
		$this->db->sql_freeresult($result);

		if (empty($forums))
		{
			return [];
		}

		$topics = !empty($topic_forum_ids)
			? $this->ranker->get_topics($topic_forum_ids, (int) $this->config['toptopics_forum_limit'])
			: [];
		$topicpreview = $this->get_topicpreview_context();
		if ($topicpreview['enabled'])
		{
			$this->assign_topicpreview_template_vars($topicpreview);
		}
		$topics = $this->decorate_topics($topics, $topicpreview['enabled'], $topicpreview);

		return [
			'forum_menu_html' => $this->build_category_forum_menu_html($forums, $category_id),
			'rows_html' => $this->build_category_rows_html($topics),
		];
	}

	protected function build_category_rows_html(array $topics): string
	{
		if (empty($topics))
		{
			return '<li class="row bg1 toptopics-category-empty">'
				. '<dl class="row-item">'
				. '<dt><div class="list-inner">' . $this->escape_text($this->language->lang('TOPTOPICS_CATEGORY_EMPTY')) . '</div></dt>'
				. '<dd class="topics">&nbsp;</dd>'
				. '<dd class="posts">&nbsp;</dd>'
				. '<dd class="lastpost">&nbsp;</dd>'
				. '</dl>'
				. '</li>';
		}

		$html = '';
		foreach ($topics as $index => $topic)
		{
			$row_class = ($index % 2 === 0) ? 'bg1' : 'bg2';
			$topic_url = append_sid($this->root_path . 'viewtopic.' . $this->php_ext, 'f=' . (int) $topic['forum_id'] . '&t=' . (int) $topic['topic_id']);
			$forum_url = append_sid($this->root_path . 'viewforum.' . $this->php_ext, 'f=' . (int) $topic['forum_id']);
			$topic_title = $this->escape_text(censor_text((string) $topic['topic_title']));
			$forum_name = $this->escape_text((string) $topic['forum_name']);
			$meta = $this->escape_text($this->language->lang('POST_BY_AUTHOR')) . ' '
				. get_username_string('full', (int) $topic['topic_poster'], $topic['topic_first_poster_name'], $topic['topic_first_poster_colour'])
				. ' &bull; ' . $this->user->format_date((int) $topic['topic_time'])
				. ' &bull; <a href="' . $forum_url . '" class="toptopics-category-badge">' . $forum_name . '</a>';

			$unread_icon = '';
			if (!empty($topic['unread_topic']) && !$this->user->data['is_bot'])
			{
				$unread_icon = '<a class="unread" href="' . $topic['u_newest_post'] . '">'
					. '<i class="icon fa-file fa-fw icon-red icon-md" aria-hidden="true"></i>'
					. '<span class="sr-only">' . $this->escape_text($this->language->lang('NEW_POST')) . '</span>'
					. '</a>';
			}

			$html .= '<li class="row ' . $row_class . ' toptopics-category-row">'
				. '<dl class="row-item ' . $this->escape_attr((string) ($topic['topic_img_style'] ?? '')) . '">'
				. '<dt title="' . $this->escape_attr((string) ($topic['topic_folder_img_alt'] ?? '')) . '">'
				. ((!empty($topic['unread_topic']) && !$this->user->data['is_bot']) ? '<a href="' . $topic['u_newest_post'] . '" class="row-item-link"></a>' : '')
				. '<div class="list-inner">'
				. $unread_icon
				. '<a href="' . $topic_url . '" class="topictitle">' . $topic_title . '</a>'
				. '<div class="toptopics-meta">' . $meta . '</div>'
				. '</div>'
				. '</dt>'
				. '<dd class="topics">' . (int) ($topic['replies'] ?? 0) . ' <dfn>' . $this->escape_text($this->language->lang('REPLIES')) . '</dfn></dd>'
				. '<dd class="posts">' . (int) ($topic['views'] ?? 0) . ' <dfn>' . $this->escape_text($this->language->lang('VIEWS')) . '</dfn></dd>'
				. '<dd class="lastpost"><span class="toptopics-signals">'
				. '<span class="toptopics-signal toptopics-signal-like"><i class="icon fa-heart fa-fw" aria-hidden="true"></i> ' . (int) ($topic['like_count'] ?? 0) . '</span>'
				. '<span class="toptopics-signal toptopics-signal-dislike"><i class="icon fa-thumbs-down fa-fw" aria-hidden="true"></i> ' . (int) ($topic['dislike_count'] ?? 0) . '</span>'
				. '<span class="toptopics-signal"><i class="icon fa-flag fa-fw" aria-hidden="true"></i> ' . (int) ($topic['flag_count'] ?? 0) . '</span>'
				. '</span></dd>'
				. '</dl>'
				. $this->build_topic_preview_html($topic)
				. '</li>';
		}

		return $html;
	}

	protected function build_topic_preview_html(array $topic): string
	{
		$preview = !empty($topic['topic_preview']) && is_array($topic['topic_preview'])
			? $topic['topic_preview']
			: [];
		$first_post = (string) ($preview['TOPIC_PREVIEW_FIRST_POST'] ?? '');
		if ($first_post === '')
		{
			return '';
		}

		$html = '<div class="topic_preview_content" style="display: none;">';
		$html .= $this->build_topic_preview_post_html(
			!empty($preview['TOPIC_PREVIEW_LAST_POST']) ? $this->language->lang('FIRST_POST') : '',
			$preview['TOPIC_PREVIEW_FIRST_AVATAR'] ?? '',
			$first_post,
			'first',
			!empty($preview['TOPIC_PREVIEW_LAST_POST'])
		);

		if (!empty($preview['TOPIC_PREVIEW_LAST_POST']))
		{
			$html .= $this->build_topic_preview_post_html(
				$this->language->lang('LAST_POST'),
				$preview['TOPIC_PREVIEW_LAST_AVATAR'] ?? '',
				(string) $preview['TOPIC_PREVIEW_LAST_POST'],
				'last',
				true
			);
		}

		$html .= '</div>';

		return $html;
	}

	protected function build_topic_preview_post_html(string $title, $avatar, string $post_text, string $post_class, bool $show_title): string
	{
		$html = '<div class="topic_preview_section">';
		if ($show_title && $title !== '')
		{
			$html .= '<strong class="topic_preview_section_title">' . $this->escape_text($title) . '</strong>';
		}

		$html .= '<div class="topic_preview_post">';
		if ($avatar !== '')
		{
			$html .= '<div class="topic_preview_avatar">' . $this->render_topic_preview_avatar_html($avatar) . '</div>';
		}

		$html .= '<div class="topic_preview_' . $this->escape_attr($post_class) . '">' . $post_text . '</div>';
		$html .= '</div></div>';

		return $html;
	}

	protected function render_topic_preview_avatar_html($avatar): string
	{
		if (is_string($avatar) && $avatar !== '' && $avatar !== 'no-avatar')
		{
			return $avatar;
		}

		return '<div class="topic_preview_no_avatar"></div>';
	}

	protected function refresh_reputation_for_visibility_event($event): void
	{
		$post_ids = $event['post_id'] ?? [];
		if (is_array($post_ids) && !empty($post_ids))
		{
			$this->refresh_reputation_for_post_ids($post_ids);
			return;
		}

		$topic_id = (int) ($event['topic_id'] ?? 0);
		if ($topic_id > 0)
		{
			$this->refresh_reputation_for_topic_id($topic_id);
		}
	}

	protected function refresh_reputation_for_post_ids(array $post_ids): void
	{
		$post_ids = array_values(array_unique(array_filter(array_map('intval', $post_ids))));
		if (empty($post_ids))
		{
			return;
		}

		$sql = 'SELECT DISTINCT poster_id
			FROM ' . POSTS_TABLE . '
			WHERE ' . $this->db->sql_in_set('post_id', $post_ids);
		$result = $this->db->sql_query($sql);
		$user_ids = [];
		while ($row = $this->db->sql_fetchrow($result))
		{
			$user_ids[] = (int) $row['poster_id'];
		}
		$this->db->sql_freeresult($result);

		$this->reputation->refresh_users($user_ids);
	}

	protected function refresh_reputation_for_topic_id(int $topic_id): void
	{
		if ($topic_id <= 0)
		{
			return;
		}

		$sql = 'SELECT DISTINCT poster_id
			FROM ' . POSTS_TABLE . '
			WHERE topic_id = ' . $topic_id;
		$result = $this->db->sql_query($sql);
		$user_ids = [];
		while ($row = $this->db->sql_fetchrow($result))
		{
			$user_ids[] = (int) $row['poster_id'];
		}
		$this->db->sql_freeresult($result);

		$this->reputation->refresh_users($user_ids);
	}

	protected function can_current_user_report(int $forum_id): bool
	{
		if ($forum_id <= 0)
		{
			return false;
		}

		if ($this->user->data['user_id'] == ANONYMOUS)
		{
			return false;
		}

		if ($this->auth->acl_get('a_board') || $this->auth->acl_get('m_report', $forum_id))
		{
			return true;
		}

		$required_score = $this->reputation->get_required_report_score();
		if ($required_score <= 0)
		{
			return true;
		}

		return $this->get_current_user_reputation() >= $required_score;
	}

	protected function get_current_user_reputation(): int
	{
		if ($this->current_user_reputation === null)
		{
			$this->current_user_reputation = $this->reputation->get_score((int) $this->user->data['user_id']);
		}

		return $this->current_user_reputation;
	}

	protected function format_reputation(int $score): string
	{
		return (string) $score;
	}

	protected function escape_text(string $text): string
	{
		return htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
	}

	protected function escape_attr(string $text): string
	{
		return htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
	}

	protected function assign_summary(array $topics, string $template_flag, string $title, bool $include_forum_name, string $collapse_id): void
	{
		if (empty($topics))
		{
			return;
		}

		$topicpreview = $this->get_topicpreview_context();
		$topics = $this->decorate_topics($topics, true, $topicpreview);
		$this->assign_topicpreview_template_vars($topicpreview);

		$collapsible = !empty($this->collapsible_operator);
		$hidden = $collapsible ? (bool) $this->collapsible_operator->is_collapsed($collapse_id) : false;
		$collapse_url = $collapsible ? $this->collapsible_operator->get_collapsible_link($collapse_id) : '';

		$this->template->assign_vars([
			$template_flag => true,
			'TOPTOPICS_BLOCK_TITLE' => $title,
			'S_TOPTOPICS_INCLUDE_FORUM_NAME' => $include_forum_name,
			'S_TOPTOPICS_COLLAPSIBLE' => $collapsible,
			'S_TOPTOPICS_HIDDEN' => $hidden,
			'U_TOPTOPICS_COLLAPSE_URL' => $collapse_url,
			'TOPTOPICS_BLOCK_ID' => $collapse_id,
		]);

		foreach ($topics as $topic)
		{
			$topic_row = [
				'U_TOPIC' => append_sid($this->root_path . 'viewtopic.' . $this->php_ext, 'f=' . (int) $topic['forum_id'] . '&t=' . (int) $topic['topic_id']),
				'U_FORUM' => append_sid($this->root_path . 'viewforum.' . $this->php_ext, 'f=' . (int) $topic['forum_id']),
				'U_NEWEST_POST' => $topic['u_newest_post'],
				'TOPIC_TITLE' => censor_text($topic['topic_title']),
				'TOPIC_IMG_STYLE' => $topic['topic_img_style'],
				'TOPIC_FOLDER_IMG_ALT' => $topic['topic_folder_img_alt'],
				'FORUM_NAME' => $topic['forum_name'],
				'USERNAME_FULL' => get_username_string('full', (int) $topic['topic_poster'], $topic['topic_first_poster_name'], $topic['topic_first_poster_colour']),
				'POST_TIME' => $this->user->format_date((int) $topic['topic_time']),
				'REPLIES' => (int) $topic['replies'],
				'VIEWS' => (int) $topic['views'],
				'LIKES' => (int) $topic['like_count'],
				'DISLIKES' => (int) $topic['dislike_count'],
				'FLAGS' => (int) $topic['flag_count'],
				'S_UNREAD_TOPIC' => !empty($topic['unread_topic']),
			];

			if (!empty($topic['topic_preview']) && is_array($topic['topic_preview']))
			{
				$topic_row = array_merge($topic_row, $topic['topic_preview']);
			}

			$this->template->assign_block_vars('top_topics', $topic_row);
		}
	}

	protected function assign_topicpreview_template_vars(array $topicpreview): void
	{
		$this->template->assign_vars([
			'S_TOPTOPICS_TOPICPREVIEW' => $topicpreview['enabled'],
			'TOPTOPICS_PREVIEW_THEME' => $topicpreview['theme'],
			'TOPTOPICS_PREVIEW_DELAY' => $topicpreview['delay'],
			'TOPTOPICS_PREVIEW_DRIFT' => $topicpreview['drift'],
			'TOPTOPICS_PREVIEW_WIDTH' => $topicpreview['width'],
		]);
	}

	protected function add_topic_tracking(array $topics): array
	{
		if (empty($topics))
		{
			return $topics;
		}

		if (!function_exists('get_complete_topic_tracking'))
		{
			include_once($this->root_path . 'includes/functions_display.' . $this->php_ext);
		}

		$topic_ids_by_forum = [];
		foreach ($topics as $topic)
		{
			$topic_ids_by_forum[(int) $topic['forum_id']][] = (int) $topic['topic_id'];
		}

		$topic_tracking_info = [];
		if ($this->config['load_anon_lastread'] || $this->user->data['is_registered'])
		{
			foreach ($topic_ids_by_forum as $forum_id => $topic_ids)
			{
				$topic_tracking_info[$forum_id] = get_complete_topic_tracking($forum_id, array_values(array_unique($topic_ids)));
			}
		}

		foreach ($topics as &$topic)
		{
			$forum_id = (int) $topic['forum_id'];
			$topic_id = (int) $topic['topic_id'];
			$topic_last_post_time = (int) ($topic['topic_last_post_time'] ?? $topic['topic_time']);

			$topic['unread_topic'] = isset($topic_tracking_info[$forum_id][$topic_id])
				&& $topic_last_post_time > (int) $topic_tracking_info[$forum_id][$topic_id];
			$topic['u_newest_post'] = append_sid(
				$this->root_path . 'viewtopic.' . $this->php_ext,
				'f=' . $forum_id . '&t=' . $topic_id
			) . '&amp;view=unread#unread';
		}
		unset($topic);

		return $topics;
	}

	protected function add_topic_display_state(array $topics): array
	{
		if (empty($topics))
		{
			return $topics;
		}

		if (!function_exists('topic_status'))
		{
			include_once($this->root_path . 'includes/functions_display.' . $this->php_ext);
		}

		foreach ($topics as &$topic)
		{
			$folder_img = '';
			$folder_alt = '';
			$topic_type = '';
			$topic_status_row = [
				'topic_status' => (int) ($topic['topic_status'] ?? ITEM_UNLOCKED),
				'topic_type' => (int) ($topic['topic_type'] ?? POST_NORMAL),
				'topic_posted' => false,
				'poll_start' => (int) ($topic['poll_start'] ?? 0),
			];

			topic_status($topic_status_row, (int) ($topic['replies'] ?? 0), !empty($topic['unread_topic']), $folder_img, $folder_alt, $topic_type);

			$topic['topic_img_style'] = $folder_img;
			$topic['topic_folder_img_alt'] = $this->language->lang($folder_alt);
		}
		unset($topic);

		return $topics;
	}

	protected function add_topic_previews(array $topics, array $topicpreview): array
	{
		if (empty($topics)
			|| empty($this->topicpreview_data)
			|| empty($this->topicpreview_renderer)
			|| !$topicpreview['enabled']
			|| !method_exists($this->topicpreview_data, 'modify_sql')
			|| !method_exists($this->topicpreview_renderer, 'render_text'))
		{
			return $topics;
		}

		$topic_ids = array_values(array_unique(array_map(static function ($topic) {
			return (int) $topic['topic_id'];
		}, $topics)));

		if (empty($topic_ids))
		{
			return $topics;
		}

		$sql_array = [
			'SELECT' => 't.topic_id, t.forum_id, t.topic_first_post_id, t.topic_last_post_id, t.topic_attachment, t.topic_poster, t.topic_last_poster_id',
			'FROM' => [
				TOPICS_TABLE => 't',
			],
			'WHERE' => $this->db->sql_in_set('t.topic_id', $topic_ids),
		];
		$sql_array = $this->topicpreview_data->modify_sql($sql_array, 'SELECT');

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);

		$preview_rows = [];
		$preview_rowset = [];
		while ($row = $this->db->sql_fetchrow($result))
		{
			$topic_id = (int) $row['topic_id'];
			$preview_rows[$topic_id] = $row;
			$preview_rowset[] = $row;
		}
		$this->db->sql_freeresult($result);

		if (empty($preview_rows))
		{
			return $topics;
		}

		$attachments = [];
		if ($topicpreview['attachments_enabled']
			&& method_exists($this->topicpreview_data, 'get_attachments_for_topics'))
		{
			$attachments = $this->topicpreview_data->get_attachments_for_topics($preview_rowset);
		}

		foreach ($topics as &$topic)
		{
			$topic_id = (int) $topic['topic_id'];
			if (isset($preview_rows[$topic_id]))
			{
				$topic['topic_preview'] = $this->build_topic_preview_vars($preview_rows[$topic_id], $attachments, $topicpreview);
			}
		}
		unset($topic);

		return $topics;
	}

	protected function build_topic_preview_vars(array $row, array $attachments, array $topicpreview): array
	{
		$first_post_id = (int) ($row['topic_first_post_id'] ?? 0);
		$last_post_id = (int) ($row['topic_last_post_id'] ?? 0);

		return [
			'TOPIC_PREVIEW_FIRST_POST' => $this->render_topic_preview_text(
				(string) ($row['first_post_text'] ?? ''),
				$first_post_id,
				(int) ($row['forum_id'] ?? 0),
				$attachments[$first_post_id] ?? [],
				$topicpreview
			),
			'TOPIC_PREVIEW_LAST_POST' => $last_post_id !== $first_post_id
				? $this->render_topic_preview_text(
					(string) ($row['last_post_text'] ?? ''),
					$last_post_id,
					(int) ($row['forum_id'] ?? 0),
					$attachments[$last_post_id] ?? [],
					$topicpreview
				)
				: '',
			'TOPIC_PREVIEW_FIRST_AVATAR' => $this->build_topic_preview_avatar($row, 'fp', $topicpreview),
			'TOPIC_PREVIEW_LAST_AVATAR' => $last_post_id !== $first_post_id
				? $this->build_topic_preview_avatar($row, 'lp', $topicpreview)
				: '',
		];
	}

	protected function render_topic_preview_text(string $text, int $post_id, int $forum_id, array $attachments, array $topicpreview): string
	{
		if (!$post_id || $text === '')
		{
			return '';
		}

		return censor_text($this->topicpreview_renderer->render_text(
			$text,
			$topicpreview['limit'],
			$topicpreview['strip_bbcodes'],
			$topicpreview['rich_text'],
			(bool) $topicpreview['theme'],
			$attachments,
			$forum_id
		));
	}

	protected function build_topic_preview_avatar(array $row, string $prefix, array $topicpreview): string
	{
		if (!$topicpreview['avatars_enabled'])
		{
			return '';
		}

		$avatar_data = [
			'user_avatar' => $row[$prefix . '_user_avatar'] ?? '',
			'user_avatar_type' => $row[$prefix . '_user_avatar_type'] ?? '',
			'user_avatar_width' => $row[$prefix . '_user_avatar_width'] ?? '',
			'user_avatar_height' => $row[$prefix . '_user_avatar_height'] ?? '',
			'username' => $row[$prefix . '_username'] ?? '',
			'user_id' => $row[$prefix . '_user_id'] ?? 0,
		];

		if (!empty($avatar_data['user_avatar']) && function_exists('phpbb_get_user_avatar'))
		{
			$avatar = phpbb_get_user_avatar($avatar_data, 'USER_AVATAR', false, true);
			if ($avatar)
			{
				return $avatar;
			}
		}

		return 'no-avatar';
	}

	protected function get_topicpreview_context(): array
	{
		$theme = false;
		$style_theme = $this->user->style['topic_preview_theme'] ?? '';
		if ($style_theme && file_exists($this->root_path . 'ext/vse/topicpreview/styles/all/theme/' . $style_theme . '.css'))
		{
			$theme = $style_theme;
		}

		$rich_text = !empty($this->config['topic_preview_rich_text']);
		$enabled = !empty($this->topicpreview_data)
			&& !empty($this->topicpreview_renderer)
			&& !empty($this->config['topic_preview_limit'])
			&& !empty($this->user->data['user_topic_preview']);

		return [
			'enabled' => $enabled,
			'theme' => $theme,
			'limit' => (int) ($this->config['topic_preview_limit'] ?? 0),
			'strip_bbcodes' => (string) ($this->config['topic_preview_strip_bbcodes'] ?? ''),
			'rich_text' => $rich_text,
			'attachments_enabled' => $rich_text
				&& !empty($this->config['topic_preview_rich_attachments'])
				&& !empty($this->config['allow_attachments']),
			'avatars_enabled' => !empty($this->config['topic_preview_avatars'])
				&& !empty($this->config['allow_avatar'])
				&& $this->user->optionget('viewavatars'),
			'delay' => max(300, (int) ($this->config['topic_preview_delay'] ?? 1000)),
			'drift' => (int) ($this->config['topic_preview_drift'] ?? 15),
			'width' => !empty($this->config['topic_preview_width']) ? (int) $this->config['topic_preview_width'] : 360,
		];
	}

	protected function increment_rank_cache_generation(): void
	{
		$this->invalidate_all_rank_cache();
	}

	protected function decorate_topics(array $topics, bool $with_previews, ?array $topicpreview = null): array
	{
		if (empty($topics))
		{
			return $topics;
		}

		$topics = $this->add_topic_tracking($topics);
		$topics = $this->add_topic_display_state($topics);

		if ($with_previews)
		{
			$topics = $this->add_topic_previews($topics, $topicpreview ?? $this->get_topicpreview_context());
		}

		return $topics;
	}

	protected function invalidate_rank_cache_for_forums(array $forum_ids): void
	{
		$this->ranker->invalidate_forums($forum_ids);
	}

	protected function invalidate_all_rank_cache(): void
	{
		$this->ranker->invalidate_all();
	}
}
